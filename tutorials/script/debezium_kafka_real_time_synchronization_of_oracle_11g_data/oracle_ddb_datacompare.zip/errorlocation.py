import pandas as pd
import numpy as np
import cx_Oracle
import dolphindb as ddb
from compare_utils import setup_logger
from compare_utils import get_config, get_oracle_value, get_oracle_table, get_ddb_value
from compare_utils import parse_oracle_table, get_oracle_ddb_relation, get_oracle_ddb_colInfo, get_transformed_columns
import dolphindb.settings as keys
import time
import uuid
import os
import logging
import warnings
warnings.filterwarnings("ignore")

def get_new_range_pklist(ddb_session, dbname, tbname, pk_names, left_idx, right_idx):
    sql = '''
        tmp_pks = select top {2}:{3} {4}
        from loadTable("{0}", "{1}")
        order by {4}
    '''.format(dbname, tbname, left_idx, right_idx, ', '.join(pk_names))
    ddb_session.run(sql)
    left_pk_dict = ddb_session.run(f"tmp_pks[0]")
    right_pk_dict = ddb_session.run(f"tmp_pks[{right_idx-left_idx-1}]")
    return left_pk_dict, right_pk_dict

def get_range_pklist_from_tmp(ddb_session, pk_names, left_idx, right_idx):
    left_pk_dict = ddb_session.run(f"tmp_pks[{left_idx}]")
    right_pk_dict = ddb_session.run(f"tmp_pks[{right_idx-1}]")
    return left_pk_dict, right_pk_dict

def gen_where_conditions(pkNames, left_pk_dict, right_pk_dict, left_include=True, right_include=True):
    where_condition = ""
    if (left_pk_dict is None and right_pk_dict is not None):
        for i in range(len(pkNames)):
            and_conditions = []
            for j in range(i+1):
                if (j >= i):
                    if left_include == True and i == len(pkNames)-1:
                        and_conditions.append(f"({pkNames[j]} <= {right_pk_dict[pkNames[j]]})")
                    else:
                        and_conditions.append(f"({pkNames[j]} < {right_pk_dict[pkNames[j]]})")
                else:
                    and_conditions.append(f"({pkNames[j]} = {right_pk_dict[pkNames[j]]})")
            where_condition += "(" + " and ".join(and_conditions) + ")"
            if i != (len(pkNames)-1):
                where_condition += "\n or"
    elif (right_pk_dict is None and left_pk_dict is not None):
        for i in range(len(pkNames)):
            and_conditions = []
            for j in range(i+1):
                if (j >= i):
                    if left_include == True and i == len(pkNames)-1:
                        and_conditions.append(f"({pkNames[j]} >= {left_pk_dict[pkNames[j]]})")
                    else:
                        and_conditions.append(f"({pkNames[j]} > {left_pk_dict[pkNames[j]]})")
                else:
                    and_conditions.append(f"({pkNames[j]} = {left_pk_dict[pkNames[j]]})")
            where_condition += "(" + " and ".join(and_conditions) + ")"
            if i != (len(pkNames)-1):
                where_condition += "\n or"
    else:
        for i in range(len(pkNames)):
            if (left_pk_dict[pkNames[i]] == right_pk_dict[pkNames[i]]):
                if i != (len(pkNames)-1):
                    continue
            if i == 0:
                if i == (len(pkNames)-1):
                    where_condition += f"({pkNames[i]} >= {left_pk_dict[pkNames[i]]} and {pkNames[i]} <= {right_pk_dict[pkNames[i]]})"
                else:
                    where_condition += f"({pkNames[i]} > {left_pk_dict[pkNames[i]]} and {pkNames[i]} < {right_pk_dict[pkNames[i]]})"
            else:
                and_conditions1 = []
                and_conditions2 = []
                for j in range(i+1):
                    if j == i:
                        if i == (len(pkNames)-1):
                            if (left_include == True):
                                and_conditions1.append(f"{pkNames[j]} >= {left_pk_dict[pkNames[j]]}")
                            else:
                                and_conditions1.append(f"{pkNames[j]} > {left_pk_dict[pkNames[j]]}")
                            if (right_include == True):
                                and_conditions2.append(f"{pkNames[j]} <= {right_pk_dict[pkNames[j]]}")
                            else:
                                and_conditions2.append(f"{pkNames[j]} < {right_pk_dict[pkNames[j]]}")
                        else:
                            and_conditions1.append(f"{pkNames[j]} > {left_pk_dict[pkNames[j]]}")
                            and_conditions2.append(f"{pkNames[j]} < {right_pk_dict[pkNames[j]]}")
                    elif j < i:
                        and_conditions1.append(f"{pkNames[j]} = {left_pk_dict[pkNames[j]]}")
                        and_conditions2.append(f"{pkNames[j]} = {right_pk_dict[pkNames[j]]}")
                    pass
                if (left_pk_dict[pkNames[i-1]] == right_pk_dict[pkNames[i-1]]):
                    if (left_pk_dict[pkNames[i]] == right_pk_dict[pkNames[i]]):
                        and_conditions1[-1] = f"{pkNames[j]} = {left_pk_dict[pkNames[j]]}"
                        where_condition += "(" + " and ".join(and_conditions1) + ")"
                    else:
                        and_conditions1.append(and_conditions2[-1])
                        where_condition += "(" + " and ".join(and_conditions1) + ")"
                else:
                    where_condition += "(" + " and ".join(and_conditions1) + ")"
                    where_condition += "\n or"
                    where_condition += "(" + " and ".join(and_conditions2) + ")"
            if i != (len(pkNames)-1):
                where_condition += "\n or"
    if where_condition != "":
        where_condition = "where " + where_condition
    return where_condition

def gen_oracle_where_condition(pk_names, left_pk_dict, right_pk_dict, left_include=True, right_include=True):
    if left_pk_dict != None:
        left_pk_dict_oracle = left_pk_dict.copy()
        for pk_name in left_pk_dict_oracle:
            pk_type = type(left_pk_dict_oracle[pk_name])
            if (pk_type == str):
                left_pk_dict_oracle[pk_name] = f"'{left_pk_dict_oracle[pk_name]}'"
            if (pk_type == np.datetime64):
                left_pk_dict_oracle[pk_name] = f"TO_DATE('{left_pk_dict_oracle[pk_name]}', 'YYYY-MM-DD')"
    else:
        left_pk_dict_oracle = None
    if right_pk_dict != None:
        right_pk_dict_oracle = right_pk_dict.copy()
        for pk_name in right_pk_dict_oracle:
            pk_type = type(right_pk_dict_oracle[pk_name])
            if (pk_type == str):
                right_pk_dict_oracle[pk_name] = f"'{right_pk_dict_oracle[pk_name]}'"
            if (pk_type == np.datetime64):
                right_pk_dict_oracle[pk_name] = f"TO_DATE('{right_pk_dict_oracle[pk_name]}', 'YYYY-MM-DD')"
    else:
        right_pk_dict_oracle = None
    where_condition = gen_where_conditions(pk_names, left_pk_dict_oracle, right_pk_dict_oracle, left_include, right_include)
    return where_condition

def gen_ddb_where_condition(pk_names, left_pk_dict, right_pk_dict, left_include=True, right_include=True):
    if left_pk_dict != None:
        left_pk_dict_ddb = left_pk_dict.copy()
        for pk_name in left_pk_dict_ddb:
            pk_type = type(left_pk_dict_ddb[pk_name])
            if (pk_type == str):
                left_pk_dict_ddb[pk_name] = f'"{left_pk_dict_ddb[pk_name]}"'
            if (pk_type == np.datetime64):
                left_pk_dict_ddb[pk_name] = left_pk_dict_ddb[pk_name].astype(str).replace("-", ".")
    else:
        left_pk_dict_ddb = None
    if right_pk_dict != None:
        right_pk_dict_ddb = right_pk_dict.copy()
        for pk_name in right_pk_dict_ddb:
            pk_type = type(right_pk_dict_ddb[pk_name])
            if (pk_type == str):
                right_pk_dict_ddb[pk_name] = f'"{right_pk_dict_ddb[pk_name]}"'
            if (pk_type == np.datetime64):
                right_pk_dict_ddb[pk_name] = right_pk_dict_ddb[pk_name].astype(str).replace("-", ".")
    else:
        right_pk_dict_ddb = None
    where_condition = gen_where_conditions(pk_names, left_pk_dict_ddb, right_pk_dict_ddb)
    return where_condition

# sql_info: dictionary
def oracle_md5_sql_with_range(sql_info_dict, pk_names, left_pk_dict, right_pk_dict, left_include=True, right_include=True, limit_size=None):
    # 组装oracle sql
    where_condition = gen_oracle_where_condition(pk_names, left_pk_dict, right_pk_dict, left_include, right_include)
    if limit_size == None:
        limit_condition = ''
    else:
        limit_condition = f' and rownum <= {limit_size}'
    oracle_md5_sql = '''
        select sum(to_number(substr(v, 1, 8), 'xxxxxxxx')) || 
        sum(to_number(substr(v, 9, 8), 'xxxxxxxx')) || 
        sum(to_number(substr(v, 17, 8), 'xxxxxxxx')) || 
        sum(to_number(substr(v, 25, 8), 'xxxxxxxx')) as ORACLE_MD5
        from ( 
            select md5(convert({0}, 'UTF8')) v 
            from {1}
            {2}
            {3}
        )
        '''.format(sql_info_dict['ORACLE_SQL'], sql_info_dict['ORACLE_TABLENAME'], where_condition, limit_condition)
    return oracle_md5_sql

def oracle_value_sql_with_range(sql_info_dict, pk_names, left_pk_dict, right_pk_dict, left_include=True, right_include=True, limit_size=None):
    where_condition = gen_oracle_where_condition(pk_names, left_pk_dict, right_pk_dict, left_include, right_include)
    if limit_size == None:
        limit_condition = ''
    else:
        limit_condition = f' and rownum <= {limit_size}'
    oracle_value_sql = '''
        select {3}, {0} ORACLE_VALUE
        from {1}
        {2}
        {4}
        order by {3}
        '''.format(sql_info_dict['ORACLE_SQL'], sql_info_dict['ORACLE_TABLENAME'], where_condition, ','.join(pk_names), limit_condition)
    return oracle_value_sql

def ddb_md5_sql_with_range(sql_info_dict, pk_names, left_pk_dict, right_pk_dict, left_include=True, right_include=True, limit_size=None):
    where_condition = gen_ddb_where_condition(pk_names, left_pk_dict, right_pk_dict, left_include, right_include)
    if limit_size == None:
        limit_condition = ''
    else:
        limit_condition = f'limit {limit_size}'
    ddb_md5_sql = '''
        exec sum(iif(v.highLong() < 0, (v.highLong() >> 32) + 4294967296, v.highLong() >> 32)) $ STRING + 
        sum(v.highLong() & 4294967295) $ STRING + 
        sum(iif(v.lowLong() < 0, (v.lowLong() >> 32) + 4294967296, v.lowLong() >> 32)) $ STRING + 
        sum(v.lowLong() & 4294967295) $ STRING 
        from (
            select md5({0}) as v
            from loadTable("{1}", "{2}")
            {3}
            {4}
        )
        '''.format(sql_info_dict['DDB_SQL'], sql_info_dict['DDB_DBNAME'], sql_info_dict['DDB_TABLENAME'], where_condition, limit_condition)
    return ddb_md5_sql

def ddb_value_sql_with_range(sql_info_dict, pk_names, left_pk_dict, right_pk_dict, left_include=True, right_include=True, limit_size=None):
    where_condition = gen_ddb_where_condition(pk_names, left_pk_dict, right_pk_dict, left_include, right_include)
    if limit_size == None:
        limit_condition = ''
    else:
        limit_condition = f'limit {limit_size}'
    ddb_value_sql = '''
        select {4}, {0} as DDB_VALUE
        from loadTable("{1}", "{2}")
        {3}
        order by {4}
        {5}
        '''.format(sql_info_dict['DDB_SQL'], sql_info_dict['DDB_DBNAME'], sql_info_dict['DDB_TABLENAME'], where_condition, ','.join(pk_names), limit_condition)
    return ddb_value_sql

def compare_oracle_ddb_table(oracle_value_table, ddb_value_table, pk_names):
    i = 0
    value_table = pd.merge(oracle_value_table, ddb_value_table, on=pk_names, how='outer')
    for i in range(len(value_table)):
        if value_table['ORACLE_VALUE'][i] !=  value_table['DDB_VALUE'][i]:
            logging.info(f"table not the same, pk names:{value_table.loc[i, pk_names].to_dict()}, oracle value: {value_table['ORACLE_VALUE'][i]}, ddb value: {value_table['DDB_VALUE'][i]}")
            return False
    return True

def get_oracle_pks(oracle_conn, ora_tbname):
    sql = '''
    select cols.column_name as pkname
    from all_constraints cons
    join all_cons_columns cols on cons.constraint_name = cols.constraint_name and cons.owner = cols.owner
    where cons.constraint_type='P' and cons.owner || '.' || cols.table_name='{0}'
    order by cols.position
    '''.format(ora_tbname)
    res = get_oracle_table(oracle_conn, sql)
    return res['PKNAME'].tolist()

def do_error_location():
    config = get_config()
    source_oracle = cx_Oracle.connect(dsn = config['oracle_host'] + ':' + str(config['oracle_port']) + '/' + config['oracle_dbname'], 
                                      user = config['oracle_user'], password = config['oracle_password'])
    oracle_cursor = source_oracle.cursor()
    sink_ddb = ddb.session(protocol=keys.PROTOCOL_DDB)
    sink_ddb.connect(config['ddb_host'], int(config['ddb_port']), config['ddb_user'], config['ddb_password'])

    oracle_table_list = parse_oracle_table(config['oracle_table_list'])
    pk_names = get_oracle_pks(source_oracle, oracle_table_list[0])
    if (len(pk_names) == 0):
        raise RuntimeError("Table with no primary key is not supported.")
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    unique_id = uuid.uuid4()
    outputfile = os.path.join(log_dir, f"errorlocation_{timestamp}_{unique_id}.log")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    setup_logger(outputfile)
    logging.info(f'Table name: {oracle_table_list[0]}, primary key: {pk_names}')
    oracle_ddb_relation = get_oracle_ddb_relation(sink_ddb, oracle_table_list, config)
    oracle_ddb_colInfo = get_oracle_ddb_colInfo(source_oracle, sink_ddb, oracle_table_list, oracle_ddb_relation, config)

    ddb_dbname = oracle_ddb_colInfo['DDB_DBNAME'][0]
    ddb_tbname = oracle_ddb_colInfo['DDB_TABLENAME'][0]
    trans_table = get_transformed_columns(oracle_ddb_colInfo, config)
    trans_sql_dict = trans_table.iloc[0].to_dict()

    # 只取DolphinDB的行数
    M = 100000
    N = 5000
    get_rows_sql = '''
        exec count(*)
        from loadTable("{0}", "{1}")
    '''.format(ddb_dbname, ddb_tbname)
    table_rows = sink_ddb.run(get_rows_sql)
    logging.info("table rows: " + str(table_rows))
    # 向下取整
    iter_M = max(int(table_rows / M), 1)
    same_flag = True
    last_pk_dict = {}
    for i in range(iter_M):
        left_pk_dict = {}
        right_pk_dict = {}
        if (i < (iter_M-1)):
            logging.info(f"Checking data...left: {i*M}, right: {(i+1)*M}")
            # get left and right primary keys of this range
            left_pk_dict, right_pk_dict = get_new_range_pklist(sink_ddb, ddb_dbname, ddb_tbname, pk_names, i*M, (i+1)*M)
            if (i == 0): 
                oracle_value_sql = oracle_value_sql_with_range(trans_sql_dict, pk_names, None, left_pk_dict, False, False, 1)
                oracle_value = get_oracle_value(oracle_cursor, oracle_value_sql)
                if oracle_value is not None:
                    logging.info(f"Data inconsistency detected, primary key:{left_pk_dict}, transformed oracle string: {oracle_value}, transformed dolphindb string: None")
                    same_flag = False
                    return
        else:
            logging.info(f"Checking data...left: {i*M}, right: {table_rows}")
            left_pk_dict, right_pk_dict = get_new_range_pklist(sink_ddb, ddb_dbname, ddb_tbname, pk_names, i*M, table_rows)
            last_pk_dict = right_pk_dict
        oracle_md5_sql = oracle_md5_sql_with_range(trans_sql_dict, pk_names, left_pk_dict, right_pk_dict)
        ddb_md5_sql = ddb_md5_sql_with_range(trans_sql_dict, pk_names, left_pk_dict, right_pk_dict)
        logging.info(f"left primary key value: {left_pk_dict}, right primary key value: {right_pk_dict}")
        # 比较md5值
        oracle_md5 = get_oracle_value(oracle_cursor, oracle_md5_sql)
        ddb_md5 = get_ddb_value(sink_ddb, ddb_md5_sql)
        logging.info(f"oracle md5: {oracle_md5}")
        logging.info(f"ddb md5: {ddb_md5}")
        if oracle_md5 != ddb_md5:
            same_flag = False
            tmp_i = i
            break
    if same_flag == False:
        logging.error(f'Table {oracle_table_list[0]} is inconsistent')
        batch_size = 0
        if (tmp_i < (iter_M-1)):
            batch_size = M
        else:
            batch_size = table_rows - i * M
        iter_N = max(int(batch_size / N), 1)
        for i in range(iter_N):
            if (i < (iter_N-1)):
                logging.info(f"Checking data...left: {tmp_i * M + i*N}, right: {tmp_i * M + (i+1)*N}")
                left_pk_dict, right_pk_dict = get_range_pklist_from_tmp(sink_ddb, pk_names, i*N, (i+1)*N)
            else:
                logging.info(f"Checking data...left: {tmp_i * M + i*N}, right: {tmp_i * M + batch_size}")
                left_pk_dict, right_pk_dict = get_range_pklist_from_tmp(sink_ddb, pk_names, i*N, batch_size)
            logging.info(left_pk_dict, right_pk_dict)
            oracle_md5_sql = oracle_md5_sql_with_range(trans_sql_dict, pk_names, left_pk_dict, right_pk_dict)
            ddb_md5_sql = ddb_md5_sql_with_range(trans_sql_dict, pk_names, left_pk_dict, right_pk_dict)
            oracle_md5 = get_oracle_value(oracle_cursor, oracle_md5_sql)
            ddb_md5 = get_ddb_value(sink_ddb, ddb_md5_sql)
            if (oracle_md5 == ddb_md5):
                logging.info(f'Check complete, Table {oracle_table_list[0]} is consistent')
            else:
                oracle_value_sql = oracle_value_sql_with_range(trans_sql_dict, pk_names, left_pk_dict, right_pk_dict)
                ddb_value_sql = ddb_value_sql_with_range(trans_sql_dict, pk_names, left_pk_dict, right_pk_dict)
                oracle_value_table = get_oracle_table(source_oracle, oracle_value_sql)
                ddb_value_table = get_ddb_value(sink_ddb, ddb_value_sql)
                res = compare_oracle_ddb_table(oracle_value_table, ddb_value_table, pk_names)
                if (res == True):
                    logging.error("The program encountered an unknown error.")
                return
    else:
        if len(last_pk_dict) > 0:
            oracle_value_sql = oracle_value_sql_with_range(trans_sql_dict, pk_names, last_pk_dict, None, False, False, 1)
            oracle_value = get_oracle_value(oracle_cursor, oracle_value_sql)
            if oracle_value is not None:
                logging.error(f"Table {oracle_table_list[0]} is inconsistent at primary key:{last_pk_dict}, transformed oracle value: {oracle_value}, transformed ddb value: None")
                same_flag = False
                return
    if same_flag == True:
        logging.info(f'Check complete, Table {oracle_table_list[0]} is consistent')

if __name__ == '__main__':
    do_error_location()