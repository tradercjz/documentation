import cx_Oracle
import dolphindb as ddb
import multiprocessing
import time
import uuid
import os
import logging
from compare_utils import setup_logger
from compare_utils import get_config, parse_oracle_table, get_oracle_value, get_ddb_value
from compare_utils import get_oracle_ddb_relation, get_oracle_ddb_colInfo, get_transformed_columns
import warnings
warnings.filterwarnings("ignore")

TYPE_ORACLE = 1
TYPE_DDB = 2

def do_compare():
    config = get_config()
    source_oracle = cx_Oracle.connect(dsn = config['oracle_host'] + ':' + str(config['oracle_port']) + '/' + config['oracle_dbname'], 
                                      user = config['oracle_user'], password = config['oracle_password'])
    sink_ddb = ddb.session()
    sink_ddb.connect(config['ddb_host'], int(config['ddb_port']), config['ddb_user'], config['ddb_password'])
    oracle_table_list = parse_oracle_table(config['oracle_table_list'])
    oracle_ddb_relation = get_oracle_ddb_relation(sink_ddb, oracle_table_list, config)
    oracle_ddb_colInfo = get_oracle_ddb_colInfo(source_oracle, sink_ddb, oracle_table_list, oracle_ddb_relation, config)
    columns_table = get_transformed_columns(oracle_ddb_colInfo, config)
    md5_sql_table = get_md5_sql_with_trans(columns_table, config['oracle_parallel'])
    manager = multiprocessing.Manager()
    table_num = len(md5_sql_table)
    task_queue = manager.Queue(table_num*2)
    result_queue = manager.Queue(table_num*2)
    source_oracle.close()
    sink_ddb.close()
    for i in range(len(md5_sql_table)):
        md5_task = {}
        md5_task['oracle_tbname'] = md5_sql_table["ORACLE_TABLENAME"][i]
        md5_task['oracle_sql'] = md5_sql_table["ORACLE_SQL"][i]
        md5_task['ddb_dbname'] = md5_sql_table["DDB_DBNAME"][i]
        md5_task['ddb_tbname'] = md5_sql_table["DDB_TABLENAME"][i]
        md5_task['ddb_sql'] = md5_sql_table["DDB_SQL"][i]
        task_queue.put(md5_task)
    
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    unique_id = uuid.uuid4()
    outputfile = os.path.join(log_dir, f"datacompare_{timestamp}_{unique_id}.log")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    setup_logger(outputfile)
    logging.info("Total number of tables to check: {0}".format(task_queue.qsize()))
    process_num = config["worker_num"]
    po = multiprocessing.Pool(process_num)
    for i in range(0, process_num):
        po.apply_async(worker, (task_queue, result_queue, config))
    po.close()
    po.join()
    logging.info("Check completed, number of result: {0}".format(result_queue.qsize()))
    count = 0
    error_count = 0
    while result_queue.empty() is not True:
        result_item = result_queue.get(True)
        if (result_item['oracle_md5'] == result_item['ddb_md5']):
            count += 1
        else:
            error_count += 1
    if (error_count > 0):
        logging.error(f"Total: {table_num}, consistent: {count}, inconsistent: {error_count}")
    else:
        logging.info(f"Total: {table_num}, consistent: {count}, inconsistent: {error_count}")

def worker(task_queue, result_queue, config):
    oracle_conn = cx_Oracle.connect(dsn = config['oracle_host'] + ':' + str(config['oracle_port']) + '/' + config['oracle_dbname'], 
                                      user = config['oracle_user'], password = config['oracle_password'])
    oracle_cursor = oracle_conn.cursor()
    ddb_session = ddb.session()
    ddb_session.connect(config['ddb_host'], int(config['ddb_port']), config['ddb_user'], config['ddb_password'])

    while task_queue.empty() is not True:
        queue_data_dict = task_queue.get(True)
        try:
            queue_data_dict["ddb_md5"] = get_ddb_value(ddb_session, queue_data_dict['ddb_sql'])
        except BaseException as e:
            queue_data_dict["ddb_md5"] = "ddb error: " + e
        try:
            queue_data_dict["oracle_md5"] = get_oracle_value(oracle_cursor, queue_data_dict['oracle_sql'])
        except BaseException as e:
            queue_data_dict["oracle_md5"] = "oracle error: " + e
        if (queue_data_dict['oracle_md5'] == queue_data_dict['ddb_md5']):
            result = "table {0} is consistent. ".format(queue_data_dict['oracle_tbname'])
        else:
            result = "table {0} is inconsistent, oracle md5 value: {1}, dolphindb md5 value: {2}. \n".format(
                queue_data_dict['oracle_tbname'], queue_data_dict['oracle_md5'], queue_data_dict['ddb_md5'])
        logging.info(result)
        result_queue.put(queue_data_dict)

    oracle_conn.close()
    ddb_session.close()

def get_md5_sql_with_trans(sql_table, oracle_parallel=1):
    for i in range(len(sql_table)):
        para_str = ''
        if (oracle_parallel > 1):
            para_str = '/*+parallel(' + str(oracle_parallel) + ')*/'
        sql_table['ORACLE_SQL'][i] = '''
        select {2} sum(to_number(substr(v, 1, 8), 'xxxxxxxx')) || 
        sum(to_number(substr(v, 9, 8), 'xxxxxxxx')) || 
        sum(to_number(substr(v, 17, 8), 'xxxxxxxx')) || 
        sum(to_number(substr(v, 25, 8), 'xxxxxxxx')) as ORACLE_MD5
        from ( 
            select md5(convert({0}, 'UTF8')) v 
            from {1}
        )
        '''.format(sql_table['ORACLE_SQL'][i], sql_table['ORACLE_TABLENAME'][i], para_str)
        sql_table['DDB_SQL'][i] = '''
        exec sum(iif(v.highLong() < 0, (v.highLong() >> 32) + 4294967296, v.highLong() >> 32)) $ STRING + 
        sum(v.highLong() & 4294967295) $ STRING + 
        sum(iif(v.lowLong() < 0, (v.lowLong() >> 32) + 4294967296, v.lowLong() >> 32)) $ STRING + 
        sum(v.lowLong() & 4294967295) $ STRING 
        from (
            select md5({0}) as v
            from loadTable("{1}", "{2}")
        )
        '''.format(sql_table['DDB_SQL'][i], sql_table['DDB_DBNAME'][i], sql_table['DDB_TABLENAME'][i])
    return sql_table

if __name__ == '__main__':
    do_compare()