import cx_Oracle
import dolphindb as ddb
from compare_utils import setup_logger
from compare_utils import get_config, parse_oracle_table, get_oracle_value, get_ddb_value
from compare_utils import get_oracle_ddb_relation
import os
import time
import uuid
import logging
import warnings
warnings.filterwarnings("ignore")

def do_rowscheck():
    config = get_config()
    source_oracle = cx_Oracle.connect(dsn = config['oracle_host'] + ':' + str(config['oracle_port']) + '/' + config['oracle_dbname'], 
                                      user = config['oracle_user'], password = config['oracle_password'])
    oracle_cursor = source_oracle.cursor()
    sink_ddb = ddb.session()
    sink_ddb.connect(config['ddb_host'], int(config['ddb_port']), config['ddb_user'], config['ddb_password'])
    oracle_table_list = parse_oracle_table(config['oracle_table_list'])
    oracle_ddb_relation = get_oracle_ddb_relation(sink_ddb, oracle_table_list, config)
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    unique_id = uuid.uuid4()
    outputfile = os.path.join(log_dir, f"rowscheck_{timestamp}_{unique_id}.log")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    setup_logger(outputfile)
    for i in range(len(oracle_ddb_relation)):
        ora_tbname = oracle_ddb_relation['ORACLE_TABLENAME'][i]
        ddb_dbname = oracle_ddb_relation['DDB_DBNAME'][i]
        ddb_tbname = oracle_ddb_relation['DDB_TABLENAME'][i]
        oracle_sql = '''
            select count(*) from {0}
        '''.format(ora_tbname)
        ddb_sql = '''
            exec count(*) from loadTable("{0}", "{1}")
        '''.format(ddb_dbname, ddb_tbname)
        oracle_count = get_oracle_value(oracle_cursor, oracle_sql)
        ddb_count = get_ddb_value(sink_ddb, ddb_sql)
        if oracle_count == ddb_count:
            logging.info("The number of rows of the table {0} is consistent, row count: {1}".format(ora_tbname, oracle_count))
        else:
            logging.error("The number of rows of the table {0} is inconsistent, oracle row count: {1}, dolphindb row count: {2}".format(ora_tbname, oracle_count, ddb_count))

if __name__ == '__main__':
    do_rowscheck()