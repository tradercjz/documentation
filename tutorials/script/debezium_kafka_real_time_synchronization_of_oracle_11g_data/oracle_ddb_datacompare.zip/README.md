# Oracle and DolphinDB data compare
1. 安装依赖：pip install cx_Oracle dolphindb，Oracle还需下载客户端

2. 在Oracle中创建md5函数，SCHEMA 需用具体校验的 Oracle 用户替换
```
CREATE OR REPLACE FUNCTION SCHEMA.MD5(str IN VARCHAR2) 
RETURN VARCHAR2
IS
    retval varchar2(4000);
BEGIN
    retval := utl_raw.cast_to_raw(DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT_STRING => str));
    RETURN retval;
END;
/
```

4. 修改config.json文件

5. 执行python datacompare.py config.json