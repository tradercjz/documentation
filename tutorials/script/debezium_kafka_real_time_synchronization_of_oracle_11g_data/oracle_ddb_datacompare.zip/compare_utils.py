import pandas as pd
import sys
import logging

def get_config():
    if len(sys.argv) > 1:
        path = sys.argv[1]
    else:
        raise ValueError("Please provide the file path as a command-line argument")
    data = pd.read_json(path)
    config = data['config']
    if 'use_config_table' not in config:
        config['use_config_table'] = False
    if 'float_mode' not in config:
        config['float_mode'] = "hex"
    if 'oracle_parallel' not in config:
        config['oracle_parallel'] = 1
    return config

def setup_logger(log_path):
    logging.basicConfig(
        filename=log_path,
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console.setFormatter(formatter)
    logging.getLogger().addHandler(console)


def parse_ddb_table(table_str):
    db_table_list = table_str.split(",")
    db_list = []
    tb_list = []
    for db_table in db_table_list:
        db_table = db_table.strip().split(".")
        db_list.append(db_table[0])
        tb_list.append(db_table[1])
    return [db_list, tb_list]

def parse_oracle_table(table_str):
    table_list = table_str.split(",")
    tb_list = []
    for tb in table_list:
        tb = tb.strip().upper()
        tb_list.append(tb)
    return tb_list

def get_oracle_value(oracle_cursor, sql):
    oracle_cursor.execute(sql)
    rows = oracle_cursor.fetchall()
    if (len(rows) > 0):
        res = rows[0][0]
    else:
        res = None
    return res

def get_oracle_table(oracle_conn, sql):
    return pd.read_sql(sql, oracle_conn)

def get_ddb_value(ddb_session, sql):
    return ddb_session.run(sql)

def get_oracle_ddb_relation(ddb_conn, ora_tblist, config):
    oracle_ddb_relation = pd.DataFrame()
    if(config['use_config_table'] == True):
        config_tb = config['config_table'].split('.')
        ddb_config_sql = '''
            select topic_name as ORACLE_TABLENAME, target_db as DDB_DBNAME, target_tab as DDB_TABLENAME from loadTable("{0}", "{1}")
            where connector_name = "ddb-sink"
        '''.format(config_tb[0], config_tb[1])
        oracle_ddb_relation = ddb_conn.run(ddb_config_sql)
        oracle_ddb_relation["ORACLE_TABLENAME"] = oracle_ddb_relation["ORACLE_TABLENAME"].str.split('.', n=1).str[-1]
        oracle_ddb_relation = oracle_ddb_relation[oracle_ddb_relation['ORACLE_TABLENAME'].isin(ora_tblist)].reset_index(drop=True)
    else:
        ddb_db_table_list = parse_ddb_table(config['ddb_table_list'])
        oracle_ddb_relation = pd.DataFrame()
        oracle_ddb_relation['ORACLE_TABLENAME'] = ora_tblist
        oracle_ddb_relation['DDB_DBNAME'] = ddb_db_table_list[0]
        oracle_ddb_relation['DDB_TABLENAME'] = ddb_db_table_list[1]
    
    return oracle_ddb_relation

def get_oracle_ddb_colInfo(ora_conn, ddb_conn, ora_tblist, oracle_ddb_relation, config):
    ddb_defs = '''
        ddb_dblist = {0}
        ddb_tblist = {1}
    '''.format(oracle_ddb_relation['DDB_DBNAME'].tolist(), oracle_ddb_relation['DDB_TABLENAME'].tolist())
    ddb_sql = '''
        ddbInfos = select ddb_dblist[0] as as DDB_DBNAME, ddb_tblist[0] as as DDB_TABLENAME, 
                upper(name) as DDB_COLNAME, typeString as DDB_COLTYPE 
                from loadTable(ddb_dblist[0], ddb_tblist[0]).schema().colDefs
        for (i in 1:size(ddb_dblist)) {
            ddbInfos = ddbInfos.unionAll(select ddb_dblist[i], ddb_tblist[i], upper(name), typeString 
            from loadTable(ddb_dblist[i], ddb_tblist[i]).schema().colDefs)
        }
        ddbInfos
    '''
    ddb_conn.run(ddb_defs)
    ddb_info = ddb_conn.run(ddb_sql)
    ddb_info = ddb_info[ddb_info['DDB_COLNAME'] != 'DUMMYSORTKEY__'].reset_index(drop=True)

    oracle_sql = '''
        SELECT OWNER || '.' || TABLE_NAME AS ORACLE_TABLENAME, COLUMN_NAME AS ORACLE_COLNAME, DATA_TYPE AS ORACLE_COLTYPE
        FROM all_tab_columns
        WHERE OWNER || '.' || TABLE_NAME in {0}
        ORDER BY table_name, column_id
        '''.format("('" + "','".join(ora_tblist) + "')")
    oracle_info = pd.read_sql(oracle_sql, ora_conn)
    meta_info = pd.merge(oracle_info, oracle_ddb_relation, on='ORACLE_TABLENAME', how='outer')

    meta_info = pd.merge(
        meta_info, ddb_info, 
        left_on=["DDB_DBNAME", "DDB_TABLENAME", "ORACLE_COLNAME"], 
        right_on=["DDB_DBNAME", "DDB_TABLENAME", "DDB_COLNAME"], how='outer')
    return meta_info

def get_transformed_columns(meta_info, config):
    # transform
    for i in range(len(meta_info)):
        ora_tbname = meta_info['ORACLE_TABLENAME'][i]
        ora_colname = meta_info['ORACLE_COLNAME'][i]
        ora_coltype = meta_info['ORACLE_COLTYPE'][i]
        ddb_colname = meta_info['DDB_COLNAME'][i]
        ddb_coltype = meta_info['DDB_COLTYPE'][i]
        if pd.isna(ora_colname) or pd.isna(ddb_colname) or ora_colname != ddb_colname:
            raise RuntimeError(f"The structure of table {ora_tbname} is inconsistent, oracle column name: {ora_colname}, dolphindb column name: {ddb_colname}")
        if ora_coltype == 'DATE':
            meta_info['ORACLE_COLNAME'][i] = 'CASE WHEN ' + ora_colname + \
            ' IS NULL THEN NULL ELSE TO_CHAR(' + ora_colname + ", 'YYYY-MM-DD HH24:MI:SS') || '.000000000' END"
        elif ora_coltype[0:9] == 'TIMESTAMP':
            meta_info['ORACLE_COLNAME'][i] = 'TO_CHAR(' + ora_colname + ", 'YYYY-MM-DD HH24:MI:SS.FF9')"
        if ddb_coltype == 'DATE' or ddb_coltype == 'DATETIME' or ddb_coltype == 'TIMESTAMP' or ddb_coltype == 'NANOTIMESTAMP':
            meta_info['DDB_COLNAME'][i] = 'temporalFormat(' + ddb_colname + ', "yyy-MM-dd HH:mm:ss.nnnnnnnnn")'
        elif ddb_coltype == 'DOUBLE' or ddb_coltype == 'FLOAT':
            if config["float_mode"] == "skipped":
                meta_info['ORACLE_COLNAME'][i] = "'" + ora_colname + "'"
                meta_info['DDB_COLNAME'][i] = "'" + ora_colname + "'"
            else: # hex mode
                meta_info['ORACLE_COLNAME'][i] = 'substr(rawtohex(to_binary_double(abs(' + ora_colname + '))), 2)'
                meta_info['DDB_COLNAME'][i] = 'iif(' + ddb_colname + ' == NULL, NULL, upper(substr(hex(abs(' + ddb_colname + ')), 1)))'
        elif ddb_coltype[0:7] == 'DECIMAL':
            meta_info['ORACLE_COLNAME'][i] = "TO_CHAR(" + ora_colname + ")"
            meta_info['DDB_COLNAME'][i] = 'iif(' + ddb_colname + ' == 0, "0", format(' + ddb_colname + ', "#."+repeat("#", 38)))'
            
    columns_table = meta_info.groupby(['ORACLE_TABLENAME', 'DDB_DBNAME', 'DDB_TABLENAME']).agg(
        ORACLE_SQL=('ORACLE_COLNAME', lambda x: ' || '.join(x)), 
        DDB_SQL=('DDB_COLNAME', lambda x: '$STRING + '.join(x) + '$STRING')).reset_index()
    return columns_table